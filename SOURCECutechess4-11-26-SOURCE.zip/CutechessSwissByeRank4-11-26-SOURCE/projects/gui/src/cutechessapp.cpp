/*
    This file is part of Cute Chess.
    Copyright (C) 2008-2018 Cute Chess authors

    Cute Chess is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Cute Chess is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Cute Chess.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "cutechessapp.h"

#include <QCoreApplication>
#include <QDir>
#include <QTime>
#include <QFileInfo>
#include <QSettings>

#include <uciengine.h>
#include <QFontInfo>
#include <QFont>
#include <QTextDocument>
#include <QTextCursor>
#include <QTextCharFormat>
#include <QColor>
#include <QPalette>
#include <QStyle>
#include <QStyleFactory>
#include <QWidget>
#include <QEvent>
#include <QLibrary>

#include <mersenne.h>
#include <enginemanager.h>
#include <gamemanager.h>
#include <board/boardfactory.h>
#include <chessgame.h>
#include <timecontrol.h>
#include <humanbuilder.h>

#include "mainwindow.h"
#include "settingsdlg.h"
#include "tournamentresultsdlg.h"
#include "gamedatabasedlg.h"
#include "gamedatabasemanager.h"
#include "importprogressdlg.h"
#include "pgnimporter.h"
#include "gamewall.h"
#ifndef Q_OS_WIN32
#	include <sys/types.h>
#	include <sys/socket.h>
#	include <pwd.h>
#	include <signal.h>
#	include <unistd.h>
#	include <cstring>
#	include <fcntl.h>
#endif


#ifndef Q_OS_WIN32
int CuteChessApplication::m_signalFd[2];
#endif

CuteChessApplication::CuteChessApplication(int& argc, char* argv[])
	: QApplication(argc, argv),
	  m_settingsDialog(nullptr),
	  m_tournamentResultsDialog(nullptr),
	  m_engineManager(nullptr),
	  m_gameManager(nullptr),
	  m_gameDatabaseManager(nullptr),
	  m_gameDatabaseDialog(nullptr),
	  m_gameWall(nullptr),
	  m_initialWindowCreated(false),
	  m_hasPendingMainWindowGeometry(false)
#ifndef Q_OS_WIN32
	  , m_signalNotifier(nullptr)
#endif
{
	{
		const quint32 seed = Mersenne::systemSeed();
		Mersenne::initialize(seed);
		qInfo("Random seed: %u", seed);
	}

	// Set the application icon
	QIcon icon;
	icon.addFile(":/icons/cutechess_512x512.png");
	icon.addFile(":/icons/cutechess_256x256.png");
	icon.addFile(":/icons/cutechess_128x128.png");
	icon.addFile(":/icons/cutechess_64x64.png");
	icon.addFile(":/icons/cutechess_32x32.png");
	icon.addFile(":/icons/cutechess_24x24.png");
	icon.addFile(":/icons/cutechess_16x16.png");
	setWindowIcon(icon);

	setQuitOnLastWindowClosed(false);

	QCoreApplication::setOrganizationName("cutechess");
	QCoreApplication::setOrganizationDomain("cutechess.com");
	QCoreApplication::setApplicationName("cutechess");
	QCoreApplication::setApplicationVersion(CUTECHESS_VERSION);

	// Use Ini format on all platforms
	QSettings::setDefaultFormat(QSettings::IniFormat);

	// Apply the saved on/off state of the UCI input filter
	UciEngine::setInputFilterEnabled(
		QSettings().value("engines/uci_input_filter", true).toBool());

	// Load the engines
	engineManager()->loadEngines(configPath() + QLatin1String("/engines.json"));

	// Read the game database state
	gameDatabaseManager()->readState(configPath() + QLatin1String("/gamedb.bin"));

	connect(this, SIGNAL(lastWindowClosed()), this, SLOT(onLastWindowClosed()));
	connect(this, SIGNAL(aboutToQuit()), this, SLOT(onAboutToQuit()));

#ifndef Q_OS_WIN32
	installSignalHandlers();
#endif

	applyCustomAppearance();
}

#ifndef Q_OS_WIN32
// Installs SIGTERM/SIGINT/SIGHUP handlers so that a session shutdown or
// "kill" of the process still goes through the normal Qt shutdown path
// (onQuitAction() -> closeAllWindows() -> ... -> aboutToQuit()) instead
// of the process just disappearing.
//
// A plain POSIX signal handler runs in a very restricted context: it can
// preempt any code, including Qt internals, at essentially any point, so
// it must not call anything that isn't async-signal-safe (this rules out
// virtually all of Qt, malloc, etc.). The standard fix is a "self-pipe":
// the handler does nothing but write a single byte to one end of a
// socket pair with write(2) (which is async-signal-safe); a
// QSocketNotifier watching the other end then wakes the Qt event loop
// and runs the real handling code (handleUnixSignal()) as perfectly
// ordinary, safe Qt code once control is back in the event loop.
void CuteChessApplication::installSignalHandlers()
{
	if (::socketpair(AF_UNIX, SOCK_STREAM, 0, m_signalFd))
	{
		qWarning("Couldn't create signal handler socket pair");
		return;
	}

	// The read end must be non-blocking: handleUnixSignal() below drains
	// it with a while (::read(...) > 0) loop, and on a blocking socket
	// that loop's final call -- made once the pipe is genuinely empty --
	// never returns instead of failing with EAGAIN/EWOULDBLOCK, which
	// would hang the Qt event loop forever and prevent
	// closeEvent()/aboutToQuit() (and the geometry write in
	// onAboutToQuit()) from ever running.
	int flags = ::fcntl(m_signalFd[1], F_GETFL, 0);
	if (flags != -1)
		::fcntl(m_signalFd[1], F_SETFL, flags | O_NONBLOCK);

	m_signalNotifier = new QSocketNotifier(m_signalFd[1], QSocketNotifier::Read, this);
	connect(m_signalNotifier, SIGNAL(activated(int)), this, SLOT(handleUnixSignal()));

	struct sigaction action;
	std::memset(&action, 0, sizeof(action));
	action.sa_handler = CuteChessApplication::unixSignalHandler;
	sigemptyset(&action.sa_mask);
	action.sa_flags = SA_RESTART;

	sigaction(SIGTERM, &action, nullptr);
	sigaction(SIGINT, &action, nullptr);
	sigaction(SIGHUP, &action, nullptr);
}

// Async-signal-safe: the only thing done here is a single write(2) to
// the self-pipe. Everything else happens later in handleUnixSignal(),
// back on the Qt event loop.
void CuteChessApplication::unixSignalHandler(int signalNumber)
{
	char signalByte = static_cast<char>(signalNumber);
	ssize_t written = ::write(m_signalFd[0], &signalByte, sizeof(signalByte));
	(void)written;
}

// Runs on the Qt event loop once unixSignalHandler() has woken
// m_signalNotifier. Drains the byte(s) from the pipe and then quits via
// exactly the same path as the Quit menu action, so closeEvent() and
// aboutToQuit() -- and therefore the settings save in onAboutToQuit() --
// run normally instead of the process just disappearing.
void CuteChessApplication::handleUnixSignal()
{
	m_signalNotifier->setEnabled(false);

	char buffer[16];
	while (::read(m_signalFd[1], buffer, sizeof(buffer)) > 0)
		;

	m_signalNotifier->setEnabled(true);

	onQuitAction();
}
#endif

// Applies the user-requested global look: mid-cream window backgrounds,
// and headings/labels rendered bold and ~1.5px larger than the platform
// default.
//
// The mid-cream colour is set on the application QPalette (Window and
// Base, plus a slightly darker AlternateBase so alternating table rows
// stay visible) rather than only via a stylesheet, because a stylesheet
// "background-color" rule does not reach every widget that needs it:
// QDockWidget panels (Moves, Tags, White's/Black's evaluation,
// Evaluation history, Engine Debug) and their floating/undocked state
// are real top-level windows outside a "QMainWindow, QDialog" selector;
// QAbstractItemView paints its viewport from QPalette::Base rather than
// from a stylesheet rule; and EvalHistory explicitly reads
// `QApplication::palette().window()` (see evalhistory.cpp). Every widget
// that doesn't override its own palette inherits the QPalette change
// automatically, so the stylesheet is now only used for the bold/larger
// heading rules, which QSS can express fine.
//
// QSS has no relative unit and no access to per-widget inherited sizes
// at parse time, so "current size + 1.5px" is approximated by reading
// the application's default font pixel size once at startup (via
// QFontInfo) and baking basePixelSize + 1.5, rounded, into the
// stylesheet as an absolute px value for QLabel / group box titles /
// dialog titles / header views / tab labels. This will drift from
// "current size + 1.5px" for any individual widget that already has a
// non-default font size set in code or in a .ui file (e.g. the
// monospace font in TournamentResultsDialog, deliberately left alone
// here).
//
// On Windows, Qt's native "windowsvista" QStyle paints QMenu (including
// its checkable/tick-box items) by asking uxtheme.dll to draw the OS's
// own menu theme parts directly, without consulting
// QPalette::Window/Text/HighlightedText, so a palette/stylesheet change
// alone does not reach Windows menus. Switching the application to the
// Qt-drawn "Fusion" QStyle before the palette is applied makes menus
// respect QPalette and QSS the same way the Linux styles already do.
// This happens right before the palette is built and set, so Fusion
// picks up the custom colours from the very first paint.
#ifdef Q_OS_WIN32
static void forceFusionStyleForReliablePaletteSupport()
{
	QStyle* fusion = QStyleFactory::create("Fusion");
	if (fusion)
		QApplication::setStyle(fusion);
}
#endif

#ifdef Q_OS_WIN32
// Native window title bars (main window, floating windows, dialogs) are
// drawn by Windows, not Qt, so neither QPalette nor a stylesheet can
// touch them; they come out white with grey text when inactive.
// Windows 11 (build 22000+) lets an application choose the caption
// colour and caption text colour per window through
// DwmSetWindowAttribute(). Use that to give every top-level window a
// caption in the same background colour as the window, with black text.
// (Windows draws native caption text in its own font, so it cannot be
// made bold.) On older Windows the call just fails and is ignored.
static void applyNativeCaptionColours(QWidget* w, const QColor& bg)
{
	typedef long (__stdcall *DwmSetWindowAttributeFn)(void*, unsigned long,
							  const void*, unsigned long);
	// Keep the library loaded for as long as the resolved function
	// pointer is used. A QLibrary local to the resolver lambda would be
	// destroyed immediately after resolution and could unload dwmapi.dll.
	static QLibrary lib(QStringLiteral("dwmapi"));
	static DwmSetWindowAttributeFn fn =
		reinterpret_cast<DwmSetWindowAttributeFn>(
			lib.resolve("DwmSetWindowAttribute"));
	if (fn == nullptr || !w->isWindow())
		return;

	void* hwnd = reinterpret_cast<void*>(w->winId());
	const unsigned long DWMWA_BORDER_COLOR = 34;
	const unsigned long DWMWA_CAPTION_COLOR = 35;
	const unsigned long DWMWA_TEXT_COLOR = 36;

	// COLORREF is 0x00BBGGRR.
	const unsigned long bgRef = static_cast<unsigned long>(
		bg.red() | (bg.green() << 8) | (bg.blue() << 16));
	const unsigned long textRef = 0x00000000; // black

	fn(hwnd, DWMWA_CAPTION_COLOR, &bgRef, sizeof(bgRef));
	fn(hwnd, DWMWA_BORDER_COLOR, &bgRef, sizeof(bgRef));
	fn(hwnd, DWMWA_TEXT_COLOR, &textRef, sizeof(textRef));
}

// Colours every top-level window as it is shown (dialogs and floating
// windows are created later than startup).
class CaptionColourFilter : public QObject
{
	public:
		explicit CaptionColourFilter(CuteChessApplication* app)
			: QObject(app), m_app(app) {}

		bool eventFilter(QObject* watched, QEvent* event) override
		{
			if (event->type() == QEvent::Show)
			{
				auto w = qobject_cast<QWidget*>(watched);
				if (w != nullptr && w->isWindow())
					applyNativeCaptionColours(w, m_app->boardBackgroundColor());
			}
			return QObject::eventFilter(watched, event);
		}

	private:
		CuteChessApplication* m_app;
};
#endif

void CuteChessApplication::applyCustomAppearance()
{
#ifdef Q_OS_WIN32
	forceFusionStyleForReliablePaletteSupport();
#endif

	const QColor midCream = boardBackgroundColor();
	const QColor midCreamAlternate = midCream.darker(105);

	// NOTE: only the background-family roles (Window/Base/AlternateBase/
	// Button) were ever set here. The foreground/text roles (WindowText,
	// Text, ButtonText) were left untouched, so they still come from
	// whatever the platform theme provides. On a session where the
	// platform theme's default text colour happens to be light (e.g. a
	// dark GTK/Qt platform theme), that leaves light/white text sitting
	// on this light cream background -- unreadable. Force a fixed dark
	// text colour on all three foreground roles so the theme is always
	// self-consistent regardless of the platform default.
	// When normal-weight text is selected the text is pure black as
	// well, not just lighter.
	const bool bold = boldTextEnabled();
	const QColor darkText = bold ? QColor(0x20, 0x20, 0x20)
				     : QColor(Qt::black);

	QPalette pal = palette();
	pal.setColor(QPalette::Window, midCream);
	pal.setColor(QPalette::Base, midCream);
	pal.setColor(QPalette::AlternateBase, midCreamAlternate);
	pal.setColor(QPalette::Button, midCream);
	pal.setColor(QPalette::WindowText, darkText);
	pal.setColor(QPalette::Text, darkText);
	pal.setColor(QPalette::ButtonText, darkText);
	setPalette(pal);

	QFontInfo baseInfo(font());
	int basePx = baseInfo.pixelSize();
	if (basePx <= 0)
		basePx = qRound(baseInfo.pointSizeF() * 96.0 / 72.0);
	int headingPx = basePx + 2; // ~1.5px, rounded up to a whole px

	// GameViewer wants two labels bumped even larger than the generic
	// heading size below (the opening name and the live tournament
	// score/Elo readout). Both are handled here via ID selectors keyed
	// off objectName(), in the same application-wide stylesheet as the
	// generic heading rule: an ID selector is more specific than a bare
	// type selector and so always wins deterministically, avoiding the
	// precedence ambiguity of mixing a widget-local stylesheet with the
	// application-wide one.
	int openingPx = basePx + 4;
	// The win-draw-loss/Elo-diff readout ("QLabel#scoreLabel") needs to
	// land pixel-identical to the engine-name label's font, but a fixed
	// or relative pixel offset can't be pinned to that label's actual
	// rendered size in advance: the engine-name label
	// (ChessClock::m_nameLabel, see chessclock.cpp) takes the plain
	// "QLabel { font-size: headingPx }" rule below as its base font, and
	// Qt's rich-text engine then bumps it again for the "<h3>" markup
	// it's wrapped in, by an amount that depends on the base font/DPI
	// and isn't exposed as a fixed ratio. Rather than guess that bump,
	// ask Qt directly: build a throwaway QTextDocument with the
	// identical base font and "<h3>" markup the engine-name label uses,
	// and read back whatever pixel size Qt actually resolves it to. The
	// score label (and any other win-draw-loss/Elo display, all of
	// which route through this same "QLabel#scoreLabel" rule) is pinned
	// to that resolved size, so it stays pixel-identical to the
	// engine-name font on any system/DPI.
	int scorePx;
	{
		QFont headingFont = font();
		headingFont.setPixelSize(headingPx);
		headingFont.setBold(true);

		QTextDocument doc;
		doc.setDefaultFont(headingFont);
		doc.setHtml(QStringLiteral("<h3>Engine Name</h3>"));

		QTextCursor cursor(&doc);
		cursor.movePosition(QTextCursor::Start);
		cursor.movePosition(QTextCursor::EndOfBlock,
				    QTextCursor::KeepAnchor);
		QTextCharFormat fmt = cursor.charFormat();

		QFontInfo resolvedInfo(fmt.font());
		scorePx = resolvedInfo.pixelSize();
		if (scorePx <= 0)
		{
			scorePx = qRound(resolvedInfo.pointSizeF()
					  * 96.0 / 72.0);
		}
		if (scorePx <= 0)
			scorePx = headingPx;
	}

	QString sheet = QString(
		// Belt-and-braces alongside the palette change above: some
		// styles/widgets read text colour from the stylesheet in
		// preference to the palette, so state it here too, in
		// addition to (not instead of) the palette fix, to guarantee
		// legible bold black text regardless of platform theme.
		"QWidget {"
		"  color: %6;"
		"  font-weight: %5;"
		"}"
		"QLabel {"
		"  font-weight: %5;"
		"  font-size: %1px;"
		"}"
		"QGroupBox::title {"
		"  font-weight: %5;"
		"  font-size: %1px;"
		"  color: #000000;"
		"  background-color: %4;"
		"}"
		// Dock-widget titles (Moves, Tags, evaluation panels, ...) are
		// NOT styled here: a "QDockWidget::title" rule does not reliably
		// reach the title on Windows. Each dock gets a self-painted
		// title bar instead (see DockTitleBar in mainwindow.cpp).
		"QHeaderView::section {"
		"  font-weight: %5;"
		"  font-size: %1px;"
		"}"
		"QTabBar::tab {"
		"  font-weight: %5;"
		"  font-size: %1px;"
		"}"
		// See the comment above: ID selectors beat the generic
		// "QLabel" rule above regardless of polish/paint timing.
		"QLabel#openingLabel {"
		"  font-weight: %5;"
		"  font-size: %2px;"
		"}"
		"QLabel#scoreLabel {"
		"  font-weight: %5;"
		"  font-size: %3px;"
		"}"
	).arg(QString::number(headingPx),
	      QString::number(openingPx),
	      QString::number(scorePx),
	      midCream.name(),
	      bold ? QStringLiteral("bold") : QStringLiteral("normal"),
	      darkText.name());

	setStyleSheet(sheet);

#ifdef Q_OS_WIN32
	// Install the caption-colour filter once; on later calls (the user
	// changed the background colour) recolour the windows already open.
	static bool captionFilterInstalled = false;
	if (!captionFilterInstalled)
	{
		installEventFilter(new CaptionColourFilter(this));
		captionFilterInstalled = true;
	}
	const QWidgetList windows = topLevelWidgets();
	for (QWidget* w : windows)
	{
		if (w->isVisible())
			applyNativeCaptionColours(w, midCream);
	}
#endif
}

bool CuteChessApplication::boldTextEnabled()
{
	return QSettings().value("ui/bold_text_enabled", true).toBool();
}

void CuteChessApplication::setBoldTextEnabled(bool enabled)
{
	QSettings().setValue("ui/bold_text_enabled", enabled);
	applyCustomAppearance();

	// Self-painted widgets (e.g. the dock title bars) read the setting
	// in their paint code, so ask every widget to repaint.
	const QWidgetList tops = topLevelWidgets();
	for (QWidget* top : tops)
	{
		top->update();
		const QList<QWidget*> children = top->findChildren<QWidget*>();
		for (QWidget* child : children)
			child->update();
	}
}

QColor CuteChessApplication::boardBackgroundColor() const
{
	// Historical default: the mid-cream #EFE6C8 that used to be
	// hard-coded in three places (here, GraphicsBoard's wall
	// colour, and BoardView's background brush). Now user
	// configurable from the Settings dialog's General tab.
	QSettings s;
	int r = s.value("ui/board_bg_color_r", 0xef).toInt();
	int g = s.value("ui/board_bg_color_g", 0xe6).toInt();
	int b = s.value("ui/board_bg_color_b", 0xc8).toInt();
	return QColor(qBound(0, r, 255), qBound(0, g, 255), qBound(0, b, 255));
}

void CuteChessApplication::setBoardBackgroundColor(const QColor& color)
{
	QSettings s;
	s.setValue("ui/board_bg_color_r", color.red());
	s.setValue("ui/board_bg_color_g", color.green());
	s.setValue("ui/board_bg_color_b", color.blue());

	// Re-derives the palette/stylesheet from the new colour.
	applyCustomAppearance();

	emit boardBackgroundColorChanged(color);
}

QColor CuteChessApplication::lightSquareColor() const
{
	// Historical default: the light tan #FFCE9E that used to be
	// hard-coded in GraphicsBoard's constructor. Now user
	// configurable from the Settings dialog's General tab.
	QSettings s;
	int r = s.value("ui/board_light_square_color_r", 0xff).toInt();
	int g = s.value("ui/board_light_square_color_g", 0xce).toInt();
	int b = s.value("ui/board_light_square_color_b", 0x9e).toInt();
	return QColor(qBound(0, r, 255), qBound(0, g, 255), qBound(0, b, 255));
}

QColor CuteChessApplication::darkSquareColor() const
{
	// Historical default: the brown #D18B47 that used to be
	// hard-coded in GraphicsBoard's constructor. Now user
	// configurable from the Settings dialog's General tab.
	QSettings s;
	int r = s.value("ui/board_dark_square_color_r", 0xd1).toInt();
	int g = s.value("ui/board_dark_square_color_g", 0x8b).toInt();
	int b = s.value("ui/board_dark_square_color_b", 0x47).toInt();
	return QColor(qBound(0, r, 255), qBound(0, g, 255), qBound(0, b, 255));
}

void CuteChessApplication::setLightSquareColor(const QColor& color)
{
	QSettings s;
	s.setValue("ui/board_light_square_color_r", color.red());
	s.setValue("ui/board_light_square_color_g", color.green());
	s.setValue("ui/board_light_square_color_b", color.blue());

	emit lightSquareColorChanged(color);
}

void CuteChessApplication::setDarkSquareColor(const QColor& color)
{
	QSettings s;
	s.setValue("ui/board_dark_square_color_r", color.red());
	s.setValue("ui/board_dark_square_color_g", color.green());
	s.setValue("ui/board_dark_square_color_b", color.blue());

	emit darkSquareColorChanged(color);
}

QColor CuteChessApplication::lightPieceColor() const
{
	QSettings s;
	int r = s.value("ui/piece_light_color_r", 0xff).toInt();
	int g = s.value("ui/piece_light_color_g", 0xff).toInt();
	int b = s.value("ui/piece_light_color_b", 0xff).toInt();
	return QColor(qBound(0, r, 255), qBound(0, g, 255), qBound(0, b, 255));
}

QColor CuteChessApplication::darkPieceColor() const
{
	QSettings s;
	int r = s.value("ui/piece_dark_color_r", 0x00).toInt();
	int g = s.value("ui/piece_dark_color_g", 0x00).toInt();
	int b = s.value("ui/piece_dark_color_b", 0x00).toInt();
	return QColor(qBound(0, r, 255), qBound(0, g, 255), qBound(0, b, 255));
}

void CuteChessApplication::setLightPieceColor(const QColor& color)
{
	QSettings s;
	s.setValue("ui/piece_light_color_r", color.red());
	s.setValue("ui/piece_light_color_g", color.green());
	s.setValue("ui/piece_light_color_b", color.blue());

	emit lightPieceColorChanged(color);
}

void CuteChessApplication::setDarkPieceColor(const QColor& color)
{
	QSettings s;
	s.setValue("ui/piece_dark_color_r", color.red());
	s.setValue("ui/piece_dark_color_g", color.green());
	s.setValue("ui/piece_dark_color_b", color.blue());

	emit darkPieceColorChanged(color);
}

bool CuteChessApplication::showBoardCoordinates() const
{
	// Defaults to on, matching Cute Chess's historical appearance.
	// User configurable from the Settings dialog's General tab.
	QSettings s;
	return s.value("ui/show_board_coordinates", true).toBool();
}

void CuteChessApplication::setShowBoardCoordinates(bool show)
{
	QSettings s;
	s.setValue("ui/show_board_coordinates", show);

	emit showBoardCoordinatesChanged(show);
}

bool CuteChessApplication::evalBarBlackAtBottom() const
{
	// Defaults to off, matching Cute Chess's historical appearance
	// (the eval bar always shows white at the bottom). User
	// configurable from the Settings dialog's General tab.
	QSettings s;
	return s.value("ui/eval_bar_black_at_bottom", false).toBool();
}

void CuteChessApplication::setEvalBarBlackAtBottom(bool blackAtBottom)
{
	QSettings s;
	s.setValue("ui/eval_bar_black_at_bottom", blackAtBottom);

	emit evalBarBlackAtBottomChanged(blackAtBottom);
}

CuteChessApplication::~CuteChessApplication()
{
	delete m_gameDatabaseDialog;
	delete m_settingsDialog;
	delete m_tournamentResultsDialog;
	delete m_gameWall;

#ifndef Q_OS_WIN32
	delete m_signalNotifier;
	::close(m_signalFd[0]);
	::close(m_signalFd[1]);
#endif
}

CuteChessApplication* CuteChessApplication::instance()
{
	return static_cast<CuteChessApplication*>(QApplication::instance());
}

QString CuteChessApplication::userName()
{
	#ifdef Q_OS_WIN32
	return qgetenv("USERNAME");
	#else
	if (QSettings().value("ui/use_full_user_name", true).toBool())
	{
		auto pwd = getpwnam(qgetenv("USER"));
		if (pwd != nullptr)
			return QString(pwd->pw_gecos).split(',')[0];
	}
	return qgetenv("USER");
	#endif
}

void CuteChessApplication::configurationRestored()
{
	// Settings that are only consulted at start-up or when a window is
	// created are pushed into the running program here.
	UciEngine::setInputFilterEnabled(
		QSettings().value("engines/uci_input_filter", true).toBool());

	if (m_gameManager != nullptr)
		m_gameManager->setConcurrency(
			QSettings().value("tournament/concurrency", 1).toInt());

	// Appearance: re-derive the palette and tell open boards/widgets.
	applyCustomAppearance();
	emit boardBackgroundColorChanged(boardBackgroundColor());
	emit lightSquareColorChanged(lightSquareColor());
	emit darkSquareColorChanged(darkSquareColor());
	emit lightPieceColorChanged(lightPieceColor());
	emit darkPieceColorChanged(darkPieceColor());
	emit showBoardCoordinatesChanged(showBoardCoordinates());
	emit evalBarBlackAtBottomChanged(evalBarBlackAtBottom());

	// The Settings dialog copies the settings into its controls when it
	// is created. Throw the old one away so the next Tools > Settings
	// shows the restored values.
	if (m_settingsDialog != nullptr)
	{
		SettingsDialog* old = m_settingsDialog;
		m_settingsDialog = nullptr;
		old->close();
		old->deleteLater();
	}
}

QString CuteChessApplication::configPath()
{
	// We want to have the exact same config path in "gui" and
	// "cli" applications so that they can share resources
	QSettings settings;
	QFileInfo fi(settings.fileName());
	QDir dir(fi.absolutePath());

	if (!dir.exists())
		dir.mkpath(fi.absolutePath());

	return fi.absolutePath();
}

EngineManager* CuteChessApplication::engineManager()
{
	if (m_engineManager == nullptr)
		m_engineManager = new EngineManager(this);

	return m_engineManager;
}

GameManager* CuteChessApplication::gameManager()
{
	if (m_gameManager == nullptr)
	{
		m_gameManager = new GameManager(this);
		int concurrency = QSettings()
			.value("tournament/concurrency", 1).toInt();
		m_gameManager->setConcurrency(concurrency);
	}

	return m_gameManager;
}

QList<MainWindow*> CuteChessApplication::gameWindows()
{
	m_gameWindows.removeAll(nullptr);

	QList<MainWindow*> gameWindowList;
	const auto gameWindows = m_gameWindows;
	for (const auto& window : gameWindows)
		gameWindowList << window.data();

	return gameWindowList;
}

MainWindow* CuteChessApplication::newGameWindow(ChessGame* game)
{
	MainWindow* mainWindow = new MainWindow(game);
	m_gameWindows.prepend(mainWindow);
	mainWindow->show();
	m_initialWindowCreated = true;

	return mainWindow;
}

void CuteChessApplication::newDefaultGame()
{
	// default game is a human versus human game using standard variant and
	// infinite time control
	ChessGame* game = new ChessGame(Chess::BoardFactory::create("standard"),
		new PgnGame());

	game->setTimeControl(TimeControl("inf"));
	game->pause();

	connect(game, SIGNAL(started(ChessGame*)),
		this, SLOT(newGameWindow(ChessGame*)));

	gameManager()->newGame(game,
			       new HumanBuilder(userName()),
			       new HumanBuilder(userName()));
}

void CuteChessApplication::showGameWindow(int index)
{
	auto gameWindow = m_gameWindows.at(index);
	gameWindow->activateWindow();
	gameWindow->raise();
}

GameDatabaseManager* CuteChessApplication::gameDatabaseManager()
{
	if (m_gameDatabaseManager == nullptr)
		m_gameDatabaseManager = new GameDatabaseManager(this);

	return m_gameDatabaseManager;
}

void CuteChessApplication::showSettingsDialog()
{
	if (m_settingsDialog == nullptr)
		m_settingsDialog = new SettingsDialog();

	showDialog(m_settingsDialog);
}

void CuteChessApplication::showTournamentResultsDialog()
{
	showDialog(tournamentResultsDialog());
}

TournamentResultsDialog*CuteChessApplication::tournamentResultsDialog()
{
	if (m_tournamentResultsDialog == nullptr)
		m_tournamentResultsDialog = new TournamentResultsDialog();

	return m_tournamentResultsDialog;
}

void CuteChessApplication::showGameDatabaseDialog()
{
	if (m_gameDatabaseDialog == nullptr)
		m_gameDatabaseDialog = new GameDatabaseDialog(gameDatabaseManager());

	showDialog(m_gameDatabaseDialog);
}

void CuteChessApplication::showGameWall()
{
	if (m_gameWall == nullptr)
	{
		m_gameWall = new GameWall(gameManager());
		auto flags = m_gameWall->windowFlags();
		m_gameWall->setWindowFlags(flags | Qt::Window);
		m_gameWall->setAttribute(Qt::WA_DeleteOnClose, true);
		m_gameWall->setWindowTitle(tr("Active Games"));
	}

	showDialog(m_gameWall);
}

void CuteChessApplication::onQuitAction()
{
	backupViewMenuState();

	// Do NOT call closeDialogs() or QApplication::closeAllWindows()
	// here. Quitting is not final until the user has answered the
	// "Stop tournament?" / "Save changes?" prompts raised from
	// MainWindow::closeEvent(), and the user may answer "No". Closing
	// the auxiliary windows up front (floating docks, Active Games,
	// tournament results, game database, settings) made them vanish
	// for good even when the quit was then cancelled. Because
	// closeEvent() always ignores the first close request and tears
	// things down asynchronously, closeAllWindows() also stopped at
	// the first window that refused, in arbitrary order, so *which*
	// window disappeared varied from run to run.
	//
	// Instead, ask just one game window to close. If the user
	// confirms, MainWindow::closeAllGames() closes the dialogs and the
	// remaining windows go down through the normal
	// GameManager::finished() -> onGameManagerFinished() path. If the
	// user declines, nothing has been touched.
	MainWindow* target = nullptr;
	const QList<MainWindow*> windows = gameWindows();
	for (MainWindow* w : windows)
	{
		if (w == nullptr)
			continue;
		if (w->isActiveWindow())
		{
			target = w;
			break;
		}
		if (target == nullptr)
			target = w;
	}

	if (target != nullptr)
		target->close();
	else
	{
		closeDialogs();
		closeAllWindows();
	}
}

void CuteChessApplication::backupViewMenuState()
{
	MainWindow* window = nullptr;
	for (MainWindow* w : gameWindows())
	{
		if (w != nullptr)
		{
			window = w;
			break;
		}
	}
	// No open window (nothing in the View menu to back up).
	if (window == nullptr)
		return;

	const QVariantMap state = window->dockVisibilityMap();

	QSettings s;
	s.beginGroup("ui");
	s.beginGroup("mainwindow");
	s.beginGroup("docks_backup");
	// Clear out any stale keys from a previous session's dock set
	// before writing the fresh snapshot, the same way a corrupted or
	// outdated set of keys shouldn't linger and be mistaken for part
	// of today's backup.
	s.remove("");
	for (auto it = state.constBegin(); it != state.constEnd(); ++it)
		s.setValue(it.key(), it.value());
	s.endGroup();
	s.endGroup();
	s.endGroup();
	s.sync();
}

void CuteChessApplication::onLastWindowClosed()
{
	if (!m_initialWindowCreated)
		return;

	if (m_gameManager != nullptr)
	{
		connect(m_gameManager, SIGNAL(finished()), this, SLOT(quit()));
		m_gameManager->finish();
	}
	else
		quit();
}

void CuteChessApplication::recordMainWindowGeometry(const QByteArray& geometry,
						      const QByteArray& windowState,
						      const QVariantMap& dockVisibility)
{
	m_pendingMainWindowGeometry = geometry;
	m_pendingMainWindowState = windowState;
	m_pendingDockVisibility = dockVisibility;
	m_hasPendingMainWindowGeometry = true;
}

void CuteChessApplication::recordDockLayouts(const QVariantMap& layouts)
{
	m_pendingDockLayouts = layouts;
}

void CuteChessApplication::onAboutToQuit()
{
	if (gameDatabaseManager()->isModified())
		gameDatabaseManager()->writeState(configPath() + QLatin1String("/gamedb.bin"));

	// This is the very last point in the application's life: every
	// window has already closed (aboutToQuit() only fires once the
	// event loop is unwinding for the final time) and nothing further
	// will run afterwards that could clobber what we're about to write.
	//
	// Earlier attempts wrote the main window's geometry to QSettings
	// from MainWindow::closeEvent() instead. That write landed on disk
	// fine, but closeEvent() does not run at the end of the
	// application's life -- it runs while windows are still being torn
	// down, with the event loop still very much alive and other
	// deferred/queued slots (tournament/game-manager shutdown, further
	// closeEvent()s on sibling windows, etc.) still to run afterwards.
	// If any of that later code touched a QSettings object for
	// anything -- even something unrelated to window geometry -- Qt's
	// shared per-file settings cache meant its eventual sync() could
	// silently carry stale (pre-close) geometry back over the value we
	// had just written, effectively resetting the saved position.
	//
	// By only ever staging the geometry in memory (see
	// recordMainWindowGeometry(), called from MainWindow as it closes)
	// and performing the actual write here, there is no longer any
	// window in which something else can re-save stale settings after
	// we've saved the real ones.
	if (m_hasPendingMainWindowGeometry)
	{
		QSettings s;
		s.beginGroup("ui");
		s.beginGroup("mainwindow");

		s.setValue("geometry", m_pendingMainWindowGeometry);
		s.setValue("window_state", m_pendingMainWindowState);

		// Each View-menu dock's ticked/visible state is also saved as
		// its own plain boolean, separately from "window_state" above.
		// See recordMainWindowGeometry()'s doc comment for why: the
		// combined saveState()/restoreState() blob is all-or-nothing,
		// so relying on it alone for dock visibility means a single
		// mismatch (e.g. a dock added/removed/renamed by an upgrade,
		// or a corrupted value) silently throws away every dock's
		// ticked state, even though the plain "geometry" value above
		// is completely unaffected and keeps restoring the window's
		// position/size correctly. That mismatch between "the window
		// comes back in the right place" and "none of the docks are
		// where they were left" is exactly what these separate,
		// independently-restorable booleans avoid.
		//
		// Written here while still nested inside "mainwindow" (i.e. to
		// "ui/mainwindow/docks"), the same group MainWindow::
		// saveDockVisibilityImmediately() and MainWindow::
		// applySavedGeometry() both use for these same keys, and the
		// same nesting depth "docks_backup" uses just below in
		// CuteChessApplication::backupViewMenuState(). An earlier
		// version of this function called s.endGroup() for
		// "mainwindow" before this point, which silently moved this
		// write to the unrelated top-level group "ui/docks" instead --
		// still internally consistent with applySavedGeometry() (which
		// had the matching premature endGroup() on its read side, so
		// the two "agreed" with each other), but orphaning
		// saveDockVisibilityImmediately()'s belt-and-braces immediate
		// write to "ui/mainwindow/docks", which nothing ever read back.
		// That silent split between two different code paths saving
		// what is supposed to be the same setting is exactly the kind
		// of fragility that let this general area of the code regress
		// more than once, so all three paths now deliberately share one
		// literal nesting.
		s.beginGroup("docks");
		for (auto it = m_pendingDockVisibility.constBegin();
		     it != m_pendingDockVisibility.constEnd(); ++it)
		{
			s.setValue(it.key(), it.value());
		}
		s.endGroup();

		// Per-dock floating state / rectangle / size, used to put a
		// dock back where it was if restoreState() could not.
		if (!m_pendingDockLayouts.isEmpty())
		{
			s.beginGroup("dock_layouts");
			for (auto it = m_pendingDockLayouts.constBegin();
			     it != m_pendingDockLayouts.constEnd(); ++it)
			{
				s.setValue(it.key(), it.value());
			}
			s.endGroup();
		}

		// Keep "docks_backup" (see backupViewMenuState()) in sync
		// with the values just written above, on every shutdown that
		// reaches this point -- not only the File > Quit / Ctrl+Q
		// route that backupViewMenuState() itself runs on. Without
		// this, a session ended by the window's own title-bar close
		// button (or anything else that skips onQuitAction() but
		// still reaches aboutToQuit(), which is every clean
		// shutdown) left "docks_backup" holding whatever the last
		// File > Quit session happened to write, arbitrarily far in
		// the past. MainWindow::verifyViewMenuAgainstBackup() at the
		// next startup treats any mismatch between that stale backup
		// and the freshly-restored "docks" values as proof the
		// normal restore failed, and overwrites the freshly-restored
		// (correct) state with the stale one -- silently undoing
		// whatever actually changed in between. Writing identical
		// values into both groups here means the two can never
		// disagree simply because of *how* the session ended.
		s.beginGroup("docks_backup");
		// Clear out any stale keys the same way backupViewMenuState()
		// does, rather than leaving one from a previous dock set
		// lying around to be mismatched against later.
		s.remove("");
		for (auto it = m_pendingDockVisibility.constBegin();
		     it != m_pendingDockVisibility.constEnd(); ++it)
		{
			s.setValue(it.key(), it.value());
		}
		s.endGroup();

		s.endGroup();
		s.endGroup();
		s.sync();
	}
}

void CuteChessApplication::showDialog(QWidget* dlg)
{
	Q_ASSERT(dlg != nullptr);

	if (dlg->isMinimized())
		dlg->showNormal();
	else
		dlg->show();

	dlg->raise();
	dlg->activateWindow();
}

void CuteChessApplication::closeDialogs()
{
	if (m_tournamentResultsDialog)
		m_tournamentResultsDialog->close();
	if (m_gameDatabaseDialog)
		m_gameDatabaseDialog->close();
	if (m_settingsDialog)
		m_settingsDialog->close();
	if (m_gameWall)
		m_gameWall->close();
}
