/*
    This file is part of Cute Chess.
    Copyright (C) 2008-2018 Cute Chess authors

    Cute Chess is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Cute Chess is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Cute Chess.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef EVALBAR_H
#define EVALBAR_H

#include <QWidget>
#include <QColor>

/*!
 * \brief A slim vertical evaluation bar shown next to the chess board.
 *
 * EvalBar shows which side is ahead, from White's point of view, as a
 * proportion of white/black fill. Unlike EvalWidget (which streams the
 * engine's live "thinking" info line-by-line while it searches), EvalBar
 * intentionally only updates once a move has actually been decided/played
 * -- i.e. only in response to ChessGame::scoreChanged(ply, score), which
 * CuteChess already emits exactly once per finished move (see
 * ChessGame::onMoveMade() / emitLastMove() in chessgame.cpp). It must
 * NOT be wired to the engine's per-iteration "info score" signal
 * (that's what EvalWidget/EvalHistory are for), or it will flicker while
 * the engine is still thinking about a move instead of only moving once
 * the move is finalized.
 *
 * By default the bar always shows white's colour at the bottom of the
 * strip, regardless of which side is displayed at the bottom of the
 * board. If the user turns on the "Show black at the bottom of the
 * evaluation bar..." preference (see setBlackAtBottomPreference()),
 * the bar instead matches the board: when the board is flipped so
 * black is at the bottom (see setBoardFlipped()), the bar's colours
 * invert too, so black's colour is at the bottom whenever black's
 * pieces are.
 *
 * Width is fixed at ~3mm, computed from the screen's logical DPI at
 * construction time (recomputed on screen change) so it stays visually
 * consistent across displays. The bar is meant to sit flush against the
 * left edge of the board in GameViewer.
 *
 * KNOWN LIMITATION / TODO (left as a log for a future session, per user
 * request): mate scores are not specially handled -- MoveEvaluation
 * already encodes forced mates as very large centipawn-like values, and
 * this widget just clamps + squashes whatever score it is given via a
 * logistic curve. A future pass should detect mate scores explicitly
 * (see MoveEvaluation / the MATE reference in moveevaluation.h) and
 * render a solid full bar + "M<n>" label instead of relying on clamping.
 */
class EvalBar : public QWidget
{
	Q_OBJECT

	public:
		explicit EvalBar(QWidget* parent = nullptr);

		QSize sizeHint() const override;

	public slots:
		//! Called once a move has been finalized. \a ply is 0-based
		//! (ply 0 = White's first move), \a score is in centipawns
		//! from the perspective of the side that just moved.
		void onScoreChanged(int ply, int score);

		//! Resets the bar to the neutral (50/50) state, e.g. for a
		//! new game.
		void clear();

		//! Tracks the board's current flip state (true when the
		//! black pieces are being displayed at the bottom of the
		//! screen). Combined with the "black at bottom" user
		//! preference (see setBlackAtBottomPreference()) to decide
		//! whether the bar itself should invert.
		void setBoardFlipped(bool flipped);

		//! Sets the user preference for whether the bar should
		//! show black's colour at the bottom when the board is
		//! flipped, instead of always keeping white at the
		//! bottom regardless of orientation.
		void setBlackAtBottomPreference(bool enabled);

		//! WORKAROUND, not a real fix: for engine-vs-engine games,
		//! the live BoardScene::flipped() signal (see
		//! setBoardFlipped()) has been unreliable at keeping the
		//! bar's colours matched to the board -- nothing is
		//! interactively flipping the board in an engine-vs-engine
		//! game, so the bug is in the signal/timing, not in the
		//! user's orientation choice. Rather than continue chasing
		//! that, this records the fact directly instead: call this
		//! once per game with whichever side is moving up the
		//! board (i.e. displayed at the bottom, advancing toward
		//! the opponent), and the bar pins its bottom colour to
		//! that side for the rest of the game, ignoring
		//! setBoardFlipped()/setBlackAtBottomPreference() entirely
		//! until clearEngineGameBottomColor() is called. Pass true
		//! if White is moving up the board, false if Black is.
		void setEngineGameBottomColor(bool whiteMovingUp);

		//! Reverts to the normal, live-tracked behaviour driven by
		//! setBoardFlipped() + setBlackAtBottomPreference(). Call
		//! this for any game where at least one side is human.
		void clearEngineGameBottomColor();

		//! Sets the colours of the two halves of the bar to match
		//! the board's pieces: \a whiteColor is used for the
		//! portion representing White (the light pieces) and
		//! \a blackColor for the portion representing Black (the
		//! dark pieces). Follows the "Board square and piece
		//! colors" settings live.
		void setPieceColors(const QColor& whiteColor, const QColor& blackColor);
		void setWhitePieceColor(const QColor& color);
		void setBlackPieceColor(const QColor& color);

	protected:
		void paintEvent(QPaintEvent* event) override;

	private:
		int m_widthPx;
		int m_score;    // last known score, White's perspective, cp
		bool m_hasScore;
		bool m_boardFlipped;         // true: black at bottom of board
		bool m_blackAtBottomPref;    // user setting, see header comment
		bool m_engineOverrideActive; // true: use m_engineBottomIsWhite below
		bool m_engineBottomIsWhite;  // recorded once per engine-vs-engine game
		QColor m_whiteColor;         // fill for White's portion (light piece colour)
		QColor m_blackColor;         // fill for Black's portion (dark piece colour)

		void updateWidthFromDpi();
};

#endif // EVALBAR_H
